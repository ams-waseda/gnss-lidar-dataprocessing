#!/bin/bash

# input is just the raw path for the data.
# Raw data folder should include:
# asterx.sbf
# hesai_lidar.pcap
# img_IR
# img_omni

# Necessary files adjacent to the script:
# IMU2bag.py
# normalize.py
# PCAPtoBag (binary)
# PCAPtoRosbag (folder)
# out.yaml
# glim_config (folder)
# postprocess.py

# You also need to install rxtools!

if [[ -z "$1" ]]; then
    echo "Error: input cannot be empty." >&2
    exit 1
fi

raw_path=$1

mkdir OUTPUT
mkdir OUTPUT/temp
mkdir OUTPUT/bags
mkdir OUTPUT/img
mkdir OUTPUT/out

# make IMU bag

bin2asc -f "${raw_path}/asterx.sbf" -t -r -m ExtSensorInfo1 -m ExtSensorMeas1 -m ExtSensorSetup1 -m ExtSensorStatus1 --precision 9 -p "OUTPUT/temp" -o "imu.txt"

python3 IMU2bag_setpath.py

bin2asc -f "${raw_path}/asterx.sbf" -m  -o asterx.pos -p "OUTPUT/temp"

# make lidar bag

./PCAPtoBag ./${raw_path}/hesai_lidar.pcap
mv "${raw_path}/lidar" "OUTPUT/bags/"

# combine bags

ros2 bag convert -i "OUTPUT/bags/imu/imu.db3" -i "OUTPUT/bags/lidar" -o out.yaml
mv "combined_bag" "OUTPUT/bags/"

# run GLIM

ros2 run glim_ros glim_rosbag OUTPUT/bags/combined_bag --ros-args -p config_path:=$(realpath glim_config)

# grab the dumpfile info

mv "/tmp/dump/traj_lidar.txt" "OUTPUT/temp/"

# normalize images

python3 normalize.py ${raw_path}/img_IR OUTPUT/img

python3 postprocess.py --glim OUTPUT/temp/traj_lidar.txt --gnss OUTPUT/temp/asterx.pos --bag OUTPUT/bags/lidar/lidar_0.mcap --img OUTPUT/img --out OUTPUT/out/pointcloud.ply
