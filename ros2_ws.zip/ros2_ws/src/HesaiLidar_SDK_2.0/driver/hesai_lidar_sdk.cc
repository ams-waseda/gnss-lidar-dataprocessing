#ifndef HESAI_LIDAR_SDK_CC_
#define HESAI_LIDAR_SDK_CC_
#include "hesai_lidar_sdk.hpp"
#endif