// generated from rosidl_generator_c/resource/idl.h.em
// with input from hesai_ros_driver:msg/Firetime.idl
// generated code does not contain a copyright notice

#ifndef HESAI_ROS_DRIVER__MSG__FIRETIME_H_
#define HESAI_ROS_DRIVER__MSG__FIRETIME_H_

#include "hesai_ros_driver/msg/detail/firetime__struct.h"
#include "hesai_ros_driver/msg/detail/firetime__functions.h"
#include "hesai_ros_driver/msg/detail/firetime__type_support.h"

#endif  // HESAI_ROS_DRIVER__MSG__FIRETIME_H_
