// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HESAI_ROS_DRIVER__MSG__PTP_HPP_
#define HESAI_ROS_DRIVER__MSG__PTP_HPP_

#include "hesai_ros_driver/msg/detail/ptp__struct.hpp"
#include "hesai_ros_driver/msg/detail/ptp__builder.hpp"
#include "hesai_ros_driver/msg/detail/ptp__traits.hpp"
#include "hesai_ros_driver/msg/detail/ptp__type_support.hpp"

#endif  // HESAI_ROS_DRIVER__MSG__PTP_HPP_
