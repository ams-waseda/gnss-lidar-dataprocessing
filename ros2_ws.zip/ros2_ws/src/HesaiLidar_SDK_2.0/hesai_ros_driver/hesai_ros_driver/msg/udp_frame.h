// generated from rosidl_generator_c/resource/idl.h.em
// with input from hesai_ros_driver:msg/UdpFrame.idl
// generated code does not contain a copyright notice

#ifndef HESAI_ROS_DRIVER__MSG__UDP_FRAME_H_
#define HESAI_ROS_DRIVER__MSG__UDP_FRAME_H_

#include "hesai_ros_driver/msg/detail/udp_frame__struct.h"
#include "hesai_ros_driver/msg/detail/udp_frame__functions.h"
#include "hesai_ros_driver/msg/detail/udp_frame__type_support.h"

#endif  // HESAI_ROS_DRIVER__MSG__UDP_FRAME_H_
