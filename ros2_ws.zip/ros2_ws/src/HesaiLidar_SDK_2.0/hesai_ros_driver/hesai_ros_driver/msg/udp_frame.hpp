// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HESAI_ROS_DRIVER__MSG__UDP_FRAME_HPP_
#define HESAI_ROS_DRIVER__MSG__UDP_FRAME_HPP_

#include "hesai_ros_driver/msg/detail/udp_frame__struct.hpp"
#include "hesai_ros_driver/msg/detail/udp_frame__builder.hpp"
#include "hesai_ros_driver/msg/detail/udp_frame__traits.hpp"
#include "hesai_ros_driver/msg/detail/udp_frame__type_support.hpp"

#endif  // HESAI_ROS_DRIVER__MSG__UDP_FRAME_HPP_
