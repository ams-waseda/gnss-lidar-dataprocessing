// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from hesai_ros_driver:msg/Ptp.idl
// generated code does not contain a copyright notice

#ifndef HESAI_ROS_DRIVER__MSG__DETAIL__PTP__TYPE_SUPPORT_H_
#define HESAI_ROS_DRIVER__MSG__DETAIL__PTP__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "hesai_ros_driver/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_hesai_ros_driver
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  hesai_ros_driver,
  msg,
  Ptp
)();

#ifdef __cplusplus
}
#endif

#endif  // HESAI_ROS_DRIVER__MSG__DETAIL__PTP__TYPE_SUPPORT_H_
