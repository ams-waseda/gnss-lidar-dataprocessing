// generated from rosidl_generator_c/resource/idl.h.em
// with input from hesai_ros_driver:msg/Ptp.idl
// generated code does not contain a copyright notice

#ifndef HESAI_ROS_DRIVER__MSG__PTP_H_
#define HESAI_ROS_DRIVER__MSG__PTP_H_

#include "hesai_ros_driver/msg/detail/ptp__struct.h"
#include "hesai_ros_driver/msg/detail/ptp__functions.h"
#include "hesai_ros_driver/msg/detail/ptp__type_support.h"

#endif  // HESAI_ROS_DRIVER__MSG__PTP_H_
