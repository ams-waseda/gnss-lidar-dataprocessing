// generated from rosidl_generator_c/resource/idl.h.em
// with input from hesai_ros_driver:msg/LossPacket.idl
// generated code does not contain a copyright notice

#ifndef HESAI_ROS_DRIVER__MSG__LOSS_PACKET_H_
#define HESAI_ROS_DRIVER__MSG__LOSS_PACKET_H_

#include "hesai_ros_driver/msg/detail/loss_packet__struct.h"
#include "hesai_ros_driver/msg/detail/loss_packet__functions.h"
#include "hesai_ros_driver/msg/detail/loss_packet__type_support.h"

#endif  // HESAI_ROS_DRIVER__MSG__LOSS_PACKET_H_
